# -*- coding: utf-8 -*-
"""
Created on Fri May  7 18:34:42 2021

@author: henco
"""
import math
import hashlib

# constants
BIT_SIZE = 32
POW = pow(2, BIT_SIZE)
rounds = 20


# mod function
def mod(value, mod_):
    return value % mod_


# right cyclic mod
def rcm(value, bits_to_move):
    mask = (value >> bits_to_move) << bits_to_move
    part = value ^ mask
    result = (part << BIT_SIZE - bits_to_move) ^ (mask >> bits_to_move)
    return result


# left cyclic mod
def lcm(value, bits_to_move):
    value = int(value)
    mask = (value >> (BIT_SIZE - bits_to_move)) << (BIT_SIZE - bits_to_move)
    part = value >> (BIT_SIZE - bits_to_move)
    result = ((value ^ mask) << bits_to_move) ^ part
    return result


# function that RC6 uses
def f(x):
    return mod(x * (2 * x + 1), POW)


# RC6 block encryption algorithm
def encrypt(values, S):

    data = values.copy()
    A, B, C, D = data
    B = mod(B + S[0], pow(2, BIT_SIZE))
    D = mod(D + S[1], pow(2, BIT_SIZE))
    data = A, B, C, D

    for i in range(2, 20 * 2 + 1, 2):
        data = [int(i) for i in data]
        A, B, C, D = data
        t = lcm(f(B), int(math.log(32, 2)))
        u = lcm(f(D), int(math.log(32, 2)))
        A = mod(lcm(A ^ t, mod(u, BIT_SIZE)) + S[i], pow(2, BIT_SIZE))
        C = mod(lcm(C ^ u, mod(t, BIT_SIZE)) + S[i + 1], pow(2, BIT_SIZE))
        data[0], data[1], data[2], data[3] = B, C, D, A

    A, B, C, D = data[0], data[1], data[2], data[3]
    A = mod(A + S[2 * 20 + 2], pow(2, BIT_SIZE))
    C = mod(C + S[2 * 20 + 3], pow(2, BIT_SIZE))

    return [A, B, C, D]


# RC6 block decryption algorithm
def decrypt(values, S):

    data = values
    A, B, C, D = data
    A = mod(A - S[42], pow(2, BIT_SIZE))
    C = mod(C - S[43], pow(2, BIT_SIZE))
    data = A, B, C, D

    g = [i for i in range(2, 41, 2)][::-1]
    for i in g:
        data = [int(i) for i in data]
        A, B, C, D = data[0], data[1], data[2], data[3]
        t_1 = lcm(f(A), int(math.log(32, 2)))
        t_2 = lcm(f(C), int(math.log(32, 2)))
        D = rcm(mod(D - S[i], pow(2, BIT_SIZE)), mod(t_2, BIT_SIZE)) ^ t_1
        B = rcm(mod(B - S[i + 1], pow(2, BIT_SIZE)), mod(t_1, BIT_SIZE)) ^ t_2
        data = D, A, B, C

    A, B, C, D = data
    D = mod(D - S[1], pow(2, BIT_SIZE))
    B = mod(B - S[0], pow(2, BIT_SIZE))

    return [A, B, C, D]

# hex digits
value_table = {
    "0": 0, "1": 1, "2": 2, "3": 3,
    "4": 4, "5": 5, "6": 6,
    "7": 7, "8": 8, "9": 9,
    "a": 10, "b": 11, "c": 12,
    "d": 13, "e": 14, "f": 15
}


# parsing string pass to int
def key_parse(main_key_STR):

    # print("main_key_STR", main_key_STR)
    mas_key_STR = [main_key_STR[(i-1)*8:i*8] for i in range(1, 5)]
    # print("mas_key_STR", mas_key_STR)
    mas_key_STR = [i[::-1] for i in mas_key_STR]
    # print("mas_key_STR", mas_key_STR)
    mas_key_INT = [math.pow(16, t)*value_table[i[t]] for i in mas_key_STR for t in range(len(i))]
    # print("mas_key_INT", mas_key_INT)
    mas_key_INT = [sum(mas_key_INT[(i-1)*8:i*8]) for i in range(1, 5)]
    # print("mas_key_INT", mas_key_INT)
    return mas_key_INT


# turing 224 bit key to 44 32-bit keys
def main_key_generation(main_key):

    P = 0xB7E151
    Q = 0x9E3779
    main_key_STR = hashlib.sha224(str(main_key).encode('utf-8')).hexdigest()
    mas_main_key_INT = key_parse(main_key_STR)
    result_mas_INT = [0 for i in range(44)]

    result_mas_INT[0] = P
    for i in range(len(result_mas_INT)-1):
        result_mas_INT[i+1] = mod(Q + result_mas_INT[i], 2**32)

    A = B = i = j = 0
    for y in range(132):
        A = result_mas_INT[i] = lcm(mod(result_mas_INT[i] + A + B, 2**32), 3)
        B = mas_main_key_INT[j] = lcm(mod(mas_main_key_INT[j] + A + B, 2**32), mod(A + B, 32))
        i = mod(i + 1, 44)
        j = mod(j + 1, 4)

    return result_mas_INT


if __name__ == '__main__':

    print(main_key_generation(22))
    print(main_key_generation(22))
    print(key_parse(hashlib.sha224(str(22).encode('utf-8')).hexdigest()))
