import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy
from RC6 import decrypt, encrypt, main_key_generation
import sys
import struct
import hashlib

# IV for OFB
IV = [126, 3, 201, 39]


# loading image from path to numpy object (gray image)
def load_image(path):

    img = mpimg.imread(path)
    image = 0.2989 * img[:, :, 0] + 0.5870 * img[:, :, 1] + 0.1140 * img[:, :, 2]
    image = numpy.array(image, dtype='uint16')
    size_of_im = image.shape

    return image, size_of_im


# turing image to byte array
def image_to_4int8_blocks(image):

    byte_list = image.flatten()
    tuple_list = numpy.reshape(byte_list, (-1, 4, 4))

    return tuple_list, len(tuple_list)


# encrypt image using RC6 algorithm (or signature)
def rc6_encrypt_image(array8_image, keys_array, signature=False):

    enc_list = []
    count_progress_bar = 0

    for to_encrypt in array8_image:

        block32 = []
        for row in to_encrypt:
            new = numpy.uint32(row[3] + (row[2] << 8) + (row[1] << 16) + (row[0] << 24))
            block32.append(new)

        enc_list.append(encrypt(block32, keys_array))

        count_progress_bar += 1

        if not signature:
            if count_progress_bar % 5000 == 0:
                sys.stdout.write('\r')
                sys.stdout.flush()
                sys.stdout.write(str(int(100 * (count_progress_bar / len(array8_image)))) + '%')

    if not signature:

        sys.stdout.write('\r')
        sys.stdout.flush()
        sys.stdout.write('100%')
        print('\nEncrypt Done!')

    return enc_list


# turns image into 32-bit blocks
def image_to_int32(array8_image):

    enc_list = []
    count_progress_bar = 0

    array8_image, _ = image_to_4int8_blocks(array8_image)

    # print(array8_image[0])
    for to_encrypt in array8_image:

        block32 = []
        for row in to_encrypt:
            new = numpy.uint32(row[0])
            new = new << 8
            new += row[1]
            new = new << 8
            new += row[2]
            new = new << 8
            new += row[3]

            block32.append(new)

        enc_list.append(block32)

        count_progress_bar += 1

    return enc_list


# turns 32-bit array back to image
def int32_list_to_image(int32_list):

    ret_image = []

    for blocks in int32_list:

        for byte in blocks:
            temp_four_bytes = numpy.flip(numpy.uint8(struct.unpack("4b", struct.pack("I", byte))))
            ret_image.append(temp_four_bytes)

    return ret_image


# decrypt image using RC6 algorithm (or signature)
def rc6_decrypt_image(array32_image, keys_array, signature=False):

    decrypt_list = []
    im_size1 = len(array32_image)
    count = 0
    for to_decrypt in array32_image:
        decrypt_list.append(decrypt(to_decrypt, keys_array))
        count += 1
        if not signature:
            if count % 5000 == 0:
                sys.stdout.write('\r')
                sys.stdout.flush()
                sys.stdout.write(str(int(100 * (count / im_size1))) + '%')

    if not signature:

        sys.stdout.write('\r')
        sys.stdout.flush()
        sys.stdout.write('100%')
        print('\nDecrypt Done!')

    list_block8 = []

    for block in decrypt_list:

        for byte in block:
            list_block8.append(numpy.flip(numpy.uint8(struct.unpack("4b", struct.pack("I", byte)))))

    return list_block8


# hashing image data
def hash_image(image_to_hash):

    string_to_hash = ''
    for row in image_to_hash:
        for pix in row:
            string_to_hash += str(pix)
    return hashlib.sha256(string_to_hash.encode('utf-8')).hexdigest()


# hash value into bytes array
def hash_to_bytes(hashed_value):

    def to_bytes(x):
        return list(x)

    i = j = 0
    int_bytes = []
    string_bytes = []
    bytes_hash = to_bytes(hashed_value)
    for chars in bytes_hash:

        if i == 0:
            string_bytes.append(chars)
            i = 1
            continue
        if i == 1:
            string_bytes[j] += chars
            j += 1
            i = 0
            continue

    for str_byte in string_bytes:
        int_bytes.append(int(str_byte, 16))

    return int_bytes


# method for creating digital signature from image, or decrypting signature
def create_MAC(value, keys_array=None, encrypt_digest=False, decrypt_digest=False):

    signature = []
    bytes_of_digest = None

    if not decrypt_digest:
        hashed_image = hash_image(value)
        bytes_of_digest = hash_to_bytes(hashed_image)

    if encrypt_digest:

        hash_int, _ = image_to_4int8_blocks(numpy.array(bytes_of_digest))

        encrypted = rc6_encrypt_image_OFB(hash_int, keys_array, signature=True)
        encrypted = int32_list_to_image(encrypted)
        for arr in encrypted:
            for val in arr:
                signature.append(val)

        return signature

    if decrypt_digest:

        to_dec = image_to_int32(numpy.array(value))

        decrypted = rc6_decrypt_image_OFB(to_dec, keys_array, signature=True)

        for arr in decrypted:
            for val in arr:
                signature.append(val)

        return signature

    return bytes_of_digest


# encrypt image using RC6 + OFB algorithm (or signature)
def rc6_encrypt_image_OFB(array8_image, keys_array, signature=False):

    enc_list = []
    count_progress_bar = 0

    feedback = list.copy(IV)

    for to_encrypt in array8_image:

        block32 = []
        for row in to_encrypt:
            new = numpy.uint32(row[3] + (row[2] << 8) + (row[1] << 16) + (row[0] << 24))
            block32.append(new)

        feedback = encrypt(feedback, keys_array)
        ciphertext = [block32[0] ^ feedback[0], block32[1] ^ feedback[1], block32[2] ^ feedback[2],
                      block32[3] ^ feedback[3]]
        enc_list.append(ciphertext)

        count_progress_bar += 1

        if not signature:
            if count_progress_bar % 5000 == 0:
                sys.stdout.write('\r')
                sys.stdout.flush()
                sys.stdout.write(str(int(100 * (count_progress_bar / len(array8_image)))) + '%')

    if not signature:

        sys.stdout.write('\r')
        sys.stdout.flush()
        sys.stdout.write('100%')
        print('\nEncrypt Done!')

    return enc_list


# decrypt image using RC6 + OFB algorithm (or signature)
def rc6_decrypt_image_OFB(array32_image, keys_array, signature=False):

    dec_list = []
    count_progress_bar = 0

    feedback = list.copy(IV)

    for to_decrypt in array32_image:

        feedback = encrypt(feedback, keys_array)
        ciphertext = [to_decrypt[0] ^ feedback[0], to_decrypt[1] ^ feedback[1], to_decrypt[2] ^ feedback[2],
                      to_decrypt[3] ^ feedback[3]]
        dec_list.append(ciphertext)

        count_progress_bar += 1

        if not signature:
            if count_progress_bar % 5000 == 0:
                sys.stdout.write('\r')
                sys.stdout.flush()
                sys.stdout.write(str(int(100 * (count_progress_bar / len(array32_image)))) + '%')

    if not signature:
        sys.stdout.write('\r')
        sys.stdout.flush()
        sys.stdout.write('100%')
        print('\nEncrypt Done!')

    list_block8 = []

    for block in dec_list:

        for byte in block:
            list_block8.append(numpy.flip(numpy.uint8(struct.unpack("4b", struct.pack("I", byte)))))

    return list_block8


if __name__ == '__main__':

    """
    alice_public, bob_public = roll_public_keys(250)
    g = 3
    prime = random.randint(1000)
    alice = KeyInfo(g, prime, alice_public)
    bob = KeyInfo(g, prime, bob_public)
    alice.receive_public_key(bob.public_key)
    bob.receive_public_key(alice.public_key)
    keys_bob = main_key_generation(bob.common_key)

    # loading image
    gr_im, size = load_image('pics/penguin.jpg')

    # transforming image to tuples of (4 bytes each)
    list_int, im_size = image_to_4int8_blocks(gr_im)

    # encrypting the list of bytes into an array of 32bit blocks
    encrypt_list = rc6_encrypt_image_OFB(list_int, keys_bob)

    # reverting back to 8 bit size blocks
    # displaying the encrypted image
    enc_image = int32_list_to_image(encrypt_list)
    result_im = (numpy.reshape(enc_image, size))
    plt.imshow(result_im, cmap='gray')
    plt.show()

    # decrypting the 32bit blocks
    list_int, _ = image_to_4int8_blocks(result_im)
    keys_alice = main_key_generation(alice.common_key)
    decrypt_image = rc6_decrypt_image_OFB(encrypt_list, keys_alice)
    # reverting back to 8 bit size blocks
    # displaying the decrypted image
    result_im = numpy.reshape(decrypt_image, size)
    plt.imshow(result_im, cmap='gray')
    plt.show()
    """
