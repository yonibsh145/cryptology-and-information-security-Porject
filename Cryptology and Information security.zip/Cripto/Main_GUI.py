import tkinter as tk
import tkinter.font as tkFont
from tkinter.filedialog import askopenfile
from PIL import Image, ImageTk
import matplotlib.pyplot as plt
from tkinter import ttk
from server import Server, Client

global online_server
global logged_client
global comboExample
global logged_on
global login_message
global pass_input
global user_input


class LoginScreen:

    def __init__(self, server_par):

        global logged_on
        global online_server
        online_server = server_par
        logged_on = False
        window = tk.Tk()
        window.resizable(False, False)

        canvas = tk.Canvas(window, width=300, height=500)
        canvas.grid(columnspan=1)

        # image
        logo = Image.open(r'pics\logo.png')
        logo = ImageTk.PhotoImage(logo)
        logo_label = tk.Label(image=logo, anchor='w')
        logo_label.image = logo
        logo_label.grid(column=0, row=0)

        # labels
        user_label = tk.Label(window, text='Username', font='Raleway')
        ft = tkFont.Font(family='Times', size=13)
        user_label["font"] = ft
        user_label["bg"] = '#ffffff'
        user_label.place(x=20, y=268, width=80, height=30)

        pass_label = tk.Label(window, text='Password', font='Raleway')
        ft = tkFont.Font(family='Times', size=13)
        pass_label["font"] = ft
        pass_label["bg"] = '#ffffff'
        pass_label.place(x=20, y=338, width=80, height=30)

        # user text
        global user_input
        user_input = tk.Text(window)
        ft = tkFont.Font(family='Times', size=15)
        user_input["font"] = ft
        user_input["bg"] = "#efefef"
        user_input.place(x=20, y=300, width=260, height=27)

        # pass text
        global pass_input
        pass_input = tk.Text(window)
        ft = tkFont.Font(family='Times', size=15)
        pass_input["font"] = ft
        pass_input["bg"] = "#efefef"
        pass_input.place(x=20, y=370, width=260, height=27)

        # login message
        global login_message
        login_message = tk.Label(window, text='', font='Raleway')
        ft = tkFont.Font(family='Times', size=11)
        login_message["font"] = ft
        login_message.place(x=50, y=435, width=200, height=30)
        login_message["bg"] = "#ffffff"
        login_message["fg"] = "#ff0000"

        def login_button_pressed():

            client = Client(user_input.get("1.0", "end-1c"), pass_input.get("1.0", "end-1c"))

            user, password, public_key_hen = client.request_login()

            try:
                public_key_server, num_of_pics_from_server = online_server.login(user, password, public_key_hen)

            except Exception as e:
                del client
                login_message['text'] = str(e)
                user_input.delete("1.0", "end-1c")
                pass_input.delete("1.0", "end-1c")
                return
            window.destroy()
            print('Logged on as \"' + client.username + '\"')
            client.receive_server_public(public_key_server, num_of_pics_from_server)
            OnlineUser(client, online_server)

        # login button
        login_button = tk.Button(window)
        login_button["bg"] = "#efefef"
        ft = tkFont.Font(family='Times', size=10)
        login_button["font"] = ft
        login_button["fg"] = "#000000"
        login_button["justify"] = "center"
        login_button["text"] = "LOGIN"
        login_button.place(x=115, y=410, width=70, height=25)
        login_button["command"] = login_button_pressed
        window.mainloop()


class OnlineUser:

    def __init__(self, client_par, server_par):

        global online_server
        online_server = server_par
        global logged_client
        logged_client = client_par
        self.username = logged_client.username
        self.pics = logged_client.database_pics
        root = tk.Tk()
        root.resizable(False, False)

        canvas = tk.Canvas(root, width=300, height=500)
        canvas.grid(columnspan=1)

        # image
        logo = Image.open(r'pics\logo.png')
        logo = ImageTk.PhotoImage(logo)
        logo_label = tk.Label(image=logo, anchor='w')
        logo_label.image = logo
        logo_label.grid(column=0, row=0)

        # text field
        path = tk.Text(root)
        ft = tkFont.Font(family='Times', size=15)
        path["font"] = ft
        path["bg"] = "#efefef"
        path.place(x=20, y=300, width=190, height=27)

        global comboExample
        # Adding combobox drop down list
        comboExample = ttk.Combobox(root,
                                    values=list(range(1, logged_client.database_pics + 1)))
        comboExample.place(x=70, y=400, width=90, height=25)
        comboExample.current()

        # labels
        select = tk.Label(root, text='Select Image to Send to Server', font='Raleway')
        ft = tkFont.Font(family='Times', size=13)
        select["font"] = ft
        select.grid(columnspan=3, columns=1, row=2)
        select.place(x=0, y=260, width=300, height=30)

        # request
        request = tk.Label(root, text='Request Image to Server', font='Raleway')
        ft = tkFont.Font(family='Times', size=13)
        request["font"] = ft
        request.grid(columnspan=3, columns=1, row=2)
        request.place(x=0, y=360, width=300, height=30)

        def select_button_pressed():

            file = askopenfile(parent=root, filetype=[('image', '*.jpg')])
            if file:
                path.insert(1.0, file.name)

                sent_pic, signature = logged_client.send_image(file.name)
                plt.imshow(sent_pic, cmap='gray')
                plt.show()

                received_from_client_pic = online_server.add_image(sent_pic, signature, logged_client.username,
                                                                   logged_client.database_pics)
                plt.imshow(received_from_client_pic, cmap='gray')
                plt.show()

                logged_client.database_pics += 1
                global comboExample
                comboExample.pack_forget()
                comboExample = ttk.Combobox(root,
                                            values=list(range(1, logged_client.database_pics + 1)))
                comboExample.place(x=70, y=400, width=90, height=25)
                comboExample.current()

        def request_button_pressed():

            image_from_server, signature = online_server.request_image(logged_client.username, comboExample.current())
            plt.imshow(image_from_server, cmap='gray')
            plt.show()

            client_dec_from_server = logged_client.receive_image(image_from_server, signature)
            plt.imshow(client_dec_from_server, cmap='gray')
            plt.show()

        # select button
        select_button = tk.Button(root)
        select_button["bg"] = "#efefef"
        ft = tkFont.Font(family='Times', size=10)
        select_button["font"] = ft
        select_button["fg"] = "#000000"
        select_button["justify"] = "center"
        select_button["text"] = "Select"
        select_button.place(x=220, y=300, width=70, height=25)
        select_button["command"] = select_button_pressed

        # request button
        request_button = tk.Button(root)
        request_button["bg"] = "#efefef"
        ft = tkFont.Font(family='Times', size=10)
        request_button["font"] = ft
        request_button["fg"] = "#000000"
        request_button["justify"] = "center"
        request_button["text"] = "Request"
        request_button.place(x=170, y=400, width=70, height=25)
        request_button["command"] = request_button_pressed

        root.mainloop()


if __name__ == '__main__':

    server = Server()
    server.users.create_account('see461', 'hencohen')
    server.users.create_account('205744550', 'yogev')
    server.users.create_account('koki', 'itay')
    server.users.create_account('shira', 'yehonatan')
    server.users.create_account('1', '1')

    login = LoginScreen(server)
