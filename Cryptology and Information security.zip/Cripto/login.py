import hashlib
import pickle


# saves object
def save_obj(obj, name):
    with open('obj/' + name + '.pkl', 'wb') as f:
        pickle.dump(obj, f, pickle.HIGHEST_PROTOCOL)


# loads object
def load_obj(name):
    with open('obj/' + name + '.pkl', 'rb') as f:
        return pickle.load(f)


class UsersData:

    def __init__(self, file_name):

        main_table = dict()
        save_obj(main_table, file_name)
        self.file_name = file_name

    # checks that the user info exits in the DB
    def check_login(self, hash_pass, username):

        table = load_obj(self.file_name)
        print()
        if table.get(username) == hash_pass:
            return True
        return False

    # saving users in python objects
    def create_account(self, user_password, username):

        table = load_obj(self.file_name)
        table[str(username)] = hashlib.sha224(str(user_password).encode('utf-8')).hexdigest()
        save_obj(table, self.file_name)


if __name__ == '__main__':

    users = UsersData('accounts')
    users.create_account('see461', 'hencohen')
    password = hashlib.sha224(str('see461').encode('utf-8')).hexdigest()
    print(users.check_login(password, 'hencohen'))
