from login import UsersData
from load_images import load_image, int32_list_to_image, image_to_4int8_blocks, rc6_encrypt_image_OFB, image_to_int32, \
    rc6_decrypt_image_OFB, create_MAC
from RC6 import main_key_generation
import hashlib
import matplotlib.pyplot as plt
from ECDH import DiffieHellman, EC
import glob
import numpy
import random
import collections
Coord = collections.namedtuple("Coord", ["x", "y"])

# NIST P-224
prime = 26959946667150639794667015087019630673557916260026308143510066298881
a = -3
b = 18958286285566608000408668544493926415504680968679321075787234672564
g = Coord(19277929113566293071110308034699488026831934219452440156649784352033,
          19926808758034470970197974370888749184205991990603949537637343198772)


class Server:

    def __init__(self):

        self.users = UsersData('accounts')
        self.pictures = dict()
        self.logged_users = dict()
        # creates an instance of the elliptic curve
        ec = EC(a, b, prime)
        self.dh = DiffieHellman(ec, g, 26959946667150639794667015087019625940457807714424391721682722368061)
        self.g = g
        self.prime = prime
        self.server_private = random.randint(1, self.dh.n - 1)
        self.server_public = self.dh.gen(self.server_private)
        image_list = []
        # load images in the DB
        for filename in glob.glob('pics/*.jpg'):
            # print(filename)
            im = load_image(filename)
            image_list.append(im)

        i = 0
        for image in image_list:

            self.pictures[i] = image
            i += 1

    # function is called when a request to login is made.
    # compared the info received with the DB data.
    # saves the public key received
    def login(self, user_password, username, public_key):

        if self.users.check_login(user_password, username):

            self.logged_users[username] = public_key

            return self.server_public, len(self.pictures)

        raise Exception('Login info not found')

    # load an image based on the image number, and encrypts it. also attaching a signature to it.
    def request_image(self, username, image_num):

        if username in self.logged_users.keys():

            pic, im_size = self.pictures[image_num]
            # transforming image to tuples of (4 bytes each)
            list_int, varssss = image_to_4int8_blocks(pic)

            Server_Common, _ = self.dh.secret(self.server_private, self.logged_users[username])
            Server_Common = main_key_generation(Server_Common)

            # encrypting the list of bytes into an array of 32bit blocks
            encrypt_list = rc6_encrypt_image_OFB(list_int, Server_Common)
            # reverting back to 8 bit size blocks
            # displaying the encrypted image

            enc_image = int32_list_to_image(encrypt_list)

            return numpy.reshape(enc_image, im_size), self.create_signeture(pic, username)

        else:
            raise Exception('user not logged in')

    # receiving an encrypted image, and decrypts it. also creating and compering the digest to the signature's digest.
    # this function adds this image to the DB
    def add_image(self, enc_image, signature_of_image, username, image_num):

        im_size = enc_image.shape
        enc_image = image_to_int32(enc_image)

        Server_Common, _ = self.dh.secret(self.server_private, self.logged_users[username])
        Server_Common = main_key_generation(Server_Common)

        decrypt_image = rc6_decrypt_image_OFB(enc_image, Server_Common)

        result_im = numpy.reshape(decrypt_image, im_size)

        digest_of_img = create_MAC(result_im)
        expected_digest = self.decrypt_signature(signature_of_image, username)

        #         print(signature)
        #         print(expected_digest)
        #         print(digest_of_img)

        if digest_of_img != expected_digest:
            raise Exception('signature not valid')

        self.pictures[image_num] = (result_im, im_size)
        return result_im

    # handles the creation of a signature from an image.
    def create_signeture(self, image, username):

        Server_Common, _ = self.dh.secret(self.server_private, self.logged_users[username])
        Server_Common = main_key_generation(Server_Common)
        sig = create_MAC(image, keys_array=Server_Common, encrypt_digest=True)
        return sig

    # handles the decrypting of the a signature.
    def decrypt_signature(self, signature_to_decrypt, username):

        Server_Common, _ = self.dh.secret(self.server_private, self.logged_users[username])
        Server_Common = main_key_generation(Server_Common)
        sig = create_MAC(signature_to_decrypt, keys_array=Server_Common, decrypt_digest=True)
        return sig


# class for client instance
class Client:

    def __init__(self, username, user_password):

        self.server_public = None
        self.database_pics = None
        self.username = username
        self.password = user_password
        cec = EC(a, b, prime)
        self.dh = DiffieHellman(cec, g, 26959946667150639794667015087019625940457807714424391721682722368061)
        self.g = g
        self.prime = prime
        self.client_private = random.randint(1, self.dh.n - 1)
        self.client_public = self.dh.gen(self.client_private)

    # send login info for the server
    def request_login(self):

        return hashlib.sha224(str(self.password).encode('utf-8')).hexdigest(), self.username, self.client_public

    # saving the servers public key and the amount of pictures in the DB.
    def receive_server_public(self, server_public_to_client, num_of_pictures):

        self.server_public = server_public_to_client
        self.database_pics = num_of_pictures

    # receiving an encrypted image, and decrypts it. also creating and compering the digest to the signature's digest.
    def receive_image(self, server_enc_image, signature_of_image):

        server_im_size = server_enc_image.shape
        server_enc_image = image_to_int32(server_enc_image)

        Client_Common, _ = self.dh.secret(self.client_private, self.server_public)
        Client_Common = main_key_generation(Client_Common)

        server_decrypt_image = rc6_decrypt_image_OFB(server_enc_image, Client_Common)

        server_result_im = numpy.reshape(server_decrypt_image, server_im_size)

        digest_of_img = create_MAC(server_result_im)
        expected_digest = self.decrypt_signature(signature_of_image)
        #         print(signature)
        #         print(expected_digest)
        #         print(digest_of_img)

        if digest_of_img != expected_digest:
            raise Exception('signature not valid')

        return server_result_im

    # load an image, and encrypts it. also attaching a signature to it.
    def send_image(self, selected_image):

        pic, im_size = load_image(selected_image)

        # transforming image to tuples of (4 bytes each)
        list_int, _ = image_to_4int8_blocks(pic)

        Client_Common, _ = self.dh.secret(self.client_private, self.server_public)
        Client_Common = main_key_generation(Client_Common)

        # encrypting the list of bytes into an array of 32bit blocks
        encrypt_list = rc6_encrypt_image_OFB(list_int, Client_Common)
        # reverting back to 8 bit size blocks
        # displaying the encrypted image

        enc_image = int32_list_to_image(encrypt_list)

        return numpy.reshape(enc_image, im_size), self.create_signature(pic)

    # handles the creation of a signature from an image.
    def create_signature(self, image):

        Client_Common, _ = self.dh.secret(self.client_private, self.server_public)
        Client_Common = main_key_generation(Client_Common)
        sig = create_MAC(image, keys_array=Client_Common, encrypt_digest=True)
        return sig

    # handles the decrypting of the a signature.
    def decrypt_signature(self, signature_to_decrypt):

        Client_Common, _ = self.dh.secret(self.client_private, self.server_public)
        Client_Common = main_key_generation(Client_Common)
        sig = create_MAC(signature_to_decrypt, keys_array=Client_Common, decrypt_digest=True)
        return sig


if __name__ == '__main__':

    # ec = EC(a, b, prime)
    #     g, _ = ec.at(0)
    #     # ECDH usage
    #     dh = DiffieHellman(ec, g)
    #
    #     Alice_priv = 15
    #     Alice_pub = dh.gen(Alice_priv)
    #     Itay_priv = 27
    #     Itay_pub = dh.gen(Itay_priv)
    #     server = Server()
    #     server.users.create_account('see461', 'hencohen')
    #     server.users.create_account('koki', 'itay')
    #     password_itay = hashlib.sha224(str('koki').encode('utf-8')).hexdigest()
    #     password_alice = hashlib.sha224(str('see461').encode('utf-8')).hexdigest()
    #
    #     server_public_key_alice = server.login(password_alice,'hencohen',Alice_pub)
    #     server_public_key_itay = server.login(password_itay,'itay',Itay_pub)
    #
    #     Itay_Common_key, y = dh.secret(server.server_private, Itay_pub)
    #     Alice_Common_key, y = dh.secret(server.server_private, Alice_pub)
    #     Server_Common_key_Alice, y = dh.secret(Alice_priv, server_public_key_alice)
    #     Server_Common_key_Itay, y = dh.secret(Itay_priv, server_public_key_itay)
    #
    #     print(Alice_Common_key,Server_Common_key_Alice)
    #     print(Itay_Common_key,Server_Common_key_Itay)
    #
    #     gr_im = server.request_image('itay', 1)
    #     plt.imshow(gr_im, cmap='gray')
    #     plt.show()
    #
    #     gr_im = server.request_image('hencohen',2)
    #     plt.imshow(gr_im, cmap='gray')
    #     plt.show()
    #
    #     server.add_image(gr_im,'hencohen',4)

    client = Client('hencohen', 'see461')
    server = Server()
    server.users.create_account('see461', 'hencohen')
    user, password, public_key_hen = client.request_login()
    server_public, num_of_pics = server.login(user, password, public_key_hen)
    client.receive_server_public(server_public, num_of_pics)

    image_from_server, signature = server.request_image(client.username, 2)
    plt.imshow(image_from_server, cmap='gray')
    plt.show()

    client_dec_from_server = client.receive_image(image_from_server, signature)
    plt.imshow(client_dec_from_server, cmap='gray')
    plt.show()

    client_sent_image, signature = client.send_image(r'pics\small_cat.jpg')
    plt.imshow(client_sent_image, cmap='gray')
    plt.show()

    server_receive_from_client = server.add_image(client_sent_image, signature, client.username, 4)
    plt.imshow(server_receive_from_client, cmap='gray')
    plt.show()
