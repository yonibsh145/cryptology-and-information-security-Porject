# Basics of Elliptic Curve Cryptography implementation on Python
import collections


def inv(n, q):
    """div on PN modulo a/b mod q as a * inv(b, q) mod q
    """
    # n*inv % q = 1 => n*inv = q*m + 1 => n*inv + q*-m = 1
    # => egcd(n, q) = (inv, -m, 1) => inv = egcd(n, q)[0] (mod q)
    return egcd(n, q)[0] % q
    # [ref] naive implementation
    # for i in range(q):
    #    if (n * i) % q == 1:
    #        return i
    #    pass
    # assert False, "unreached"
    # pass


def egcd(a, b):
    """extended GCD
    returns: (s, t, gcd) as a*s + b*t == gcd
    """
    s0, s1, t0, t1 = 1, 0, 0, 1
    while b > 0:
        q, r = divmod(a, b)
        a, b = b, r
        s0, s1, t0, t1 = s1, s0 - q * s1, t1, t0 - q * t1
        pass
    return s0, t0, a


def sqrt(n, q):
    """sqrt on PN modulo: returns two numbers or exception if not exist
    """
    assert n < q
    for i in range(1, q):
        if i * i % q == n:
            return (i, q - i)
        pass
    raise Exception("not found")


Coord = collections.namedtuple("Coord", ["x", "y"])


class EC(object):
    """System of Elliptic Curve"""

    def __init__(self, a, b, q):
        """elliptic curve as: (y**2 = x**3 + a * x + b) mod q
        - a, b: params of curve formula
        - q: prime number
        """
        self.a = a
        self.b = b
        self.q = q
        # just as unique ZERO value representation for "add": (not on curve)
        self.zero = Coord(0, 0)
        pass

    def is_valid(self, p):
        if p == self.zero: return True
        l = (p.y ** 2) % self.q
        r = ((p.x ** 3) + self.a * p.x + self.b) % self.q
        return l == r

    def at(self, x):
        """find points on curve at x
        - x: int < q
        - returns: ((x, y), (x,-y)) or not found exception
        """
        assert x < self.q

        ysq = (x ** 3 + self.a * x + self.b) % self.q
        y, my = sqrt(ysq, self.q)

        return Coord(x, y), Coord(x, my)

    def neg(self, p):
        """negate p
        """
        return Coord(p.x, -p.y % self.q)

    def add(self, p1, p2):
        """<add> of elliptic curve: negate of 3rd cross point of (p1,p2) line
        """
        if p1 == self.zero: return p2
        if p2 == self.zero: return p1
        if p1.x == p2.x and (p1.y != p2.y or p1.y == 0):
            # p1 + -p1 == 0
            return self.zero
        if p1.x == p2.x:
            # p1 + p1: use tangent line of p1 as (p1,p1) line
            l = (3 * p1.x * p1.x + self.a) * inv(2 * p1.y, self.q) % self.q
            pass
        else:
            l = (p2.y - p1.y) * inv(p2.x - p1.x, self.q) % self.q
            pass
        x = (l * l - p1.x - p2.x) % self.q
        y = (l * (p1.x - x) - p1.y) % self.q
        return Coord(x, y)

    def mul(self, p, n):
        """n times <mul> of elliptic curve
        """
        r = self.zero
        m2 = p
        # O(log2(n)) add
        while 0 < n:
            if n & 1 == 1:
                r = self.add(r, m2)
                pass
            n, m2 = n >> 1, self.add(m2, m2)
            pass
        # [ref] O(n) add
        # for i in range(n):
        #    r = self.add(r, p)
        #    pass
        return r

    def order(self, g):
        """order of point g
        """
        assert self.is_valid(g) and g != self.zero
        for i in range(1, self.q + 1):
            if self.mul(g, i) == self.zero:
                return i
            pass
            # print(self.mul(g, i))

        raise Exception("Invalid order")

    pass


class DiffieHellman(object):
    """Elliptic Curve Diffie Hellman (Key Agreement)
    - ec: elliptic curve
    - g: a point on ec
    """

    def __init__(self, ec, g, order):
        self.ec = ec
        self.g = g
        self.n = order

        pass

    def gen(self, priv):
        """generate pub key"""
        assert 0 < priv and priv < self.n
        return self.ec.mul(self.g, priv)

    def secret(self, priv, pub):
        """calc shared secret key for the pair
        - priv: my private key as int
        - pub: partner pub key as a point on ec
        - returns: shared secret as a point on ec
        """
        return self.ec.mul(pub, priv)

    pass


if __name__ == "__main__":
    # shared elliptic curve system of examples
    prime = 26959946667150639794667015087019630673557916260026308143510066298881
    a = -3
    b = 18958286285566608000408668544493926415504680968679321075787234672564
    print('///')

    ec = EC(a, b, prime)

    print('///')

    g = Coord(19277929113566293071110308034699488026831934219452440156649784352033, 19926808758034470970197974370888749184205991990603949537637343198772)
    print('///')

    # ECDH usage
    dh = DiffieHellman(ec, g, 26959946667150639794667015087019625940457807714424391721682722368061)
    print('///')

    apriv = 15
    apub = dh.gen(apriv)
    print('///')

    bpriv = 29
    bpub = dh.gen(bpriv)
    print('///')

    cpriv = 7
    cpub = dh.gen(cpriv)
    # same secret on each pair
    print('///')

    x,y = dh.secret(apriv, bpub)
    x1,y1 = dh.secret(bpriv, apub)
    print( x,y ,'|', x1 ,y1)
    print( dh.secret(apriv, cpub), dh.secret(cpriv, apub))
    print( dh.secret(bpriv, cpub), dh.secret(cpriv, bpub))

    # not same secret on other pair
    print( dh.secret(apriv, cpub), dh.secret(apriv, bpub))
    print( dh.secret(bpriv, apub), dh.secret(bpriv, cpub))
    print( dh.secret(cpriv, bpub), dh.secret(cpriv, apub))